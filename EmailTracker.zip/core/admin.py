from django.contrib import admin
from .models import Recipient
# Register your models here.

admin.site.register(Recipient)
